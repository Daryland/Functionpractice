export const PEOPLE = [
  { id: 1, name: 'Melisa', age: 23 },
  { id: 2, name: 'John', age: 43 },
  { id: 3, name: 'Michael', age: 54 },
]
